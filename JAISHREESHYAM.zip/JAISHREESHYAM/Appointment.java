package com.barbershop.model;

import java.util.Date;

public class Appointment {
    private int id;
    private User user;
    private Barber barber;
    private Service service;
    private Date appointmentDate;
    private String status;
    
    // Constructors
    public Appointment() {
    }
    
    public Appointment(int id, User user, Barber barber, Service service, Date appointmentDate, String status) {
        this.id = id;
        this.user = user;
        this.barber = barber;
        this.service = service;
        this.appointmentDate = appointmentDate;
        this.status = status;
    }
    
    // Getters and Setters
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public User getUser() {
        return user;
    }
    
    public void setUser(User user) {
        this.user = user;
    }
    
    public Barber getBarber() {
        return barber;
    }
    
    public void setBarber(Barber barber) {
        this.barber = barber;
    }
    
    public Service getService() {
        return service;
    }
    
    public void setService(Service service) {
        this.service = service;
    }
    
    public Date getAppointmentDate() {
        return appointmentDate;
    }
    
    public void setAppointmentDate(Date appointmentDate) {
        this.appointmentDate = appointmentDate;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
}