package com.barbershop.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.barbershop.model.Appointment;
import com.barbershop.model.Barber;
import com.barbershop.model.Service;
import com.barbershop.model.User;
import com.barbershop.util.DatabaseUtil;

public class AppointmentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        String action = request.getParameter("action");
        
        if ("book".equals(action)) {
            // Load barbers and services for booking form
            loadBarberAndServices(request, response);
        } else {
            // Display user's appointments
            loadUserAppointments(request, response, user.getId());
        }
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        String action = request.getParameter("action");
        
        if ("book".equals(action)) {
            // Book a new appointment
            bookAppointment(request, response, user.getId());
        } else if ("cancel".equals(action)) {
            // Cancel an appointment
            cancelAppointment(request, response, user.getId());
        }
    }
    
    private void loadBarberAndServices(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Connection conn = null;
        PreparedStatement stmtBarbers = null;
        PreparedStatement stmtServices = null;
        ResultSet rsBarbers = null;
        ResultSet rsServices = null;
        
        try {
            conn = DatabaseUtil.getConnection();
            
            // Load barbers
            String sqlBarbers = "SELECT * FROM barbers";
            stmtBarbers = conn.prepareStatement(sqlBarbers);
            rsBarbers = stmtBarbers.executeQuery();
            
            List<Barber> barbers = new ArrayList<>();
            while (rsBarbers.next()) {
                Barber barber = new Barber();
                barber.setId(rsBarbers.getInt("id"));
                barber.setName(rsBarbers.getString("name"));
                barber.setSpecialization(rsBarbers.getString("specialization"));
                barber.setYearsOfExperience(rsBarbers.getInt("years_of_experience"));
                barbers.add(barber);
            }
            
            // Load services
            String sqlServices = "SELECT * FROM services";
            stmtServices = conn.prepareStatement(sqlServices);
            rsServices = stmtServices.executeQuery();
            
            List<Service> services = new ArrayList<>();
            while (rsServices.next()) {
                Service service = new Service();
                service.setId(rsServices.getInt("id"));
                service.setName(rsServices.getString("name"));
                service.setDescription(rsServices.getString("description"));
                service.setPrice(rsServices.getDouble("price"));
                service.setDurationMinutes(rsServices.getInt("duration_minutes"));
                services.add(service);
            }
            
            request.setAttribute("barbers", barbers);
            request.setAttribute("services", services);
            request.getRequestDispatcher("/book-appointment.jsp").forward(request, response);
            
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Database error: " + e.getMessage());
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        } finally {
            // Close resources
            try {
                if (rsBarbers != null) rsBarbers.close();
                if (rsServices != null) rsServices.close();
                if (stmtBarbers != null) stmtBarbers.close();
                if (stmtServices != null) stmtServices.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            DatabaseUtil.closeConnection(conn);
        }
    }
    
    private void loadUserAppointments(HttpServletRequest request, HttpServletResponse response, int userId) throws ServletException, IOException {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            conn = DatabaseUtil.getConnection();
            
            // Load user appointments with join to get barber and service info
            String sql = "SELECT a.*, b.name as barber_name, b.specialization, s.name as service_name, s.price " +
                          "FROM appointments a " +
                          "JOIN barbers b ON a.barber_id = b.id " +
                          "JOIN services s ON a.service_id = s.id " +
                          "WHERE a.user_id = ? " +
                          "ORDER BY a.appointment_date";
            
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, userId);
            rs = stmt.executeQuery();
            
            List<Appointment> appointments = new ArrayList<>();
            while (rs.next()) {
                Appointment appointment = new Appointment();
                appointment.setId(rs.getInt("id"));
                
                // Set barber
                Barber barber = new Barber();
                barber.setId(rs.getInt("barber_id"));
                barber.setName(rs.getString("barber_name"));
                barber.setSpecialization(rs.getString("specialization"));
                appointment.setBarber(barber);
                
                // Set service
                Service service = new Service();
                service.setId(rs.getInt("service_id"));
                service.setName(rs.getString("service_name"));
                service.setPrice(rs.getDouble("price"));
                appointment.setService(service);
                
                appointment.setAppointmentDate(rs.getTimestamp("appointment_date"));
                appointment.setStatus(rs.getString("status"));
                
                appointments.add(appointment);
            }
            
            request.setAttribute("appointments", appointments);
            request.getRequestDispatcher("/my-appointments.jsp").forward(request, response);
            
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Database error: " + e.getMessage());
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        } finally {
            // Close resources
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            DatabaseUtil.closeConnection(conn);
        }
    }
    
    private void bookAppointment(HttpServletRequest request, HttpServletResponse response, int userId) throws ServletException, IOException {
        int barberId = Integer.parseInt(request.getParameter("barberId"));
        int serviceId = Integer.parseInt(request.getParameter("serviceId"));
        String appointmentDate = request.getParameter("appointmentDate");
        String appointmentTime = request.getParameter("appointmentTime");
        
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {
            // Combine date and time
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
            Date date = dateFormat.parse(appointmentDate + " " + appointmentTime);
            java.sql.Timestamp sqlDate = new java.sql.Timestamp(date.getTime());
            
            conn = DatabaseUtil.getConnection();
            String sql = "INSERT INTO appointments (user_id, barber_id, service_id, appointment_date, status) VALUES (?, ?, ?, ?, 'Pending')";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, userId);
            stmt.setInt(2, barberId);
            stmt.setInt(3, serviceId);
            stmt.setTimestamp(4, sqlDate);
            
            int rowsAffected = stmt.executeUpdate();
            
            if (rowsAffected > 0) {
                // Booking successful
                request.setAttribute("successMessage", "Appointment booked successfully!");
            } else {
                // Booking failed
                request.setAttribute("errorMessage", "Failed to book appointment. Please try again.");
            }
            
            response.sendRedirect(request.getContextPath() + "/appointments");
            
        } catch (SQLException | ParseException e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Error: " + e.getMessage());
            loadBarberAndServices(request, response);
        } finally {
            // Close resources
            try {
                if (stmt != null) stmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            DatabaseUtil.closeConnection(conn);
        }
    }
    
    private void cancelAppointment(HttpServletRequest request, HttpServletResponse response, int userId) throws ServletException, IOException {
        int appointmentId = Integer.parseInt(request.getParameter("appointmentId"));
        
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {
            conn = DatabaseUtil.getConnection();
            
            // Verify the appointment belongs to the user
            String sql = "UPDATE appointments SET status = 'Cancelled' WHERE id = ? AND user_id = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, appointmentId);
            stmt.setInt(2, userId);
            
            int rowsAffected = stmt.executeUpdate();
            
            if (rowsAffected > 0) {
                // Cancellation successful
                request.setAttribute("successMessage", "Appointment cancelled successfully!");
            } else {
                // Cancellation failed
                request.setAttribute("errorMessage", "Failed to cancel appointment. Please try again.");
            }
            
            response.sendRedirect(request.getContextPath() + "/appointments");
            
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Database error: " + e.getMessage());
            loadUserAppointments(request, response, userId);
        } finally {
            // Close resources
            try {
                if (stmt != null) stmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            DatabaseUtil.closeConnection(conn);
        }
    }
}