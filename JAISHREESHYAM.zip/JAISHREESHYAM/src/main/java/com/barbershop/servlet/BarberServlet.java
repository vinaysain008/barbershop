package com.barbershop.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.barbershop.model.Barber;
import com.barbershop.util.DatabaseUtil;

public class BarberServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            conn = DatabaseUtil.getConnection();
            String sql = "SELECT * FROM barbers";
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();
            
            List<Barber> barbers = new ArrayList<>();
            while (rs.next()) {
                Barber barber = new Barber();
                barber.setId(rs.getInt("id"));
                barber.setName(rs.getString("name"));
                barber.setSpecialization(rs.getString("specialization"));
                barber.setYearsOfExperience(rs.getInt("years_of_experience"));
                barbers.add(barber);
            }
            
            request.setAttribute("barbers", barbers);
            request.getRequestDispatcher("/barbers.jsp").forward(request, response);
            
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Database error: " + e.getMessage());
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        } finally {
            // Close resources
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            DatabaseUtil.closeConnection(conn);
        }
    }
}